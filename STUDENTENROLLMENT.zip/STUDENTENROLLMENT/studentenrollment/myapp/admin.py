# from django.contrib import admin

# # Register your models here.
# # Register your models here.
# from.models import *
# admin.site.register(CourseTeacher)

# admin.site.register(Student)

# admin.site.register(Enrollment)


from django.contrib import admin
from .models import CourseTeacher, Student, Enrollment

# Register the CourseTeacher model
@admin.register(CourseTeacher)
class CourseTeacherAdmin(admin.ModelAdmin):
    list_display = ('course_name', 'teacher_name')
    search_fields = ('course_name', 'teacher_name')

# Register the Student model
@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('s_name', 'email', 's_semester', 's_degree')
    search_fields = ('s_name', 'email', 's_semester', 's_degree')
    filter_horizontal = ('courses',)

# Register the Enrollment model
@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student', 'course_teacher', 'enroll_date')
    search_fields = ('student__s_name', 'course_teacher__course_name', 'enroll_date')


