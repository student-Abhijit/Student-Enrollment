from django.shortcuts import render,HttpResponse,redirect
from.models import *

from pprint import pprint
# Create your views here.
def index(request):
    return render(request,"reg.html")

def registration(request):
    if request.method=="POST":
        s_name = request.POST['s_name']
        email = request.POST['email']
        password = request.POST['password']
        s_semester = request.POST['s_semester']
        s_degree=request.POST['s_degree']
        
        data=Student(s_name=s_name,email=email,password=password,s_semester=s_semester,s_degree=s_degree)
        
        data.save()
        return redirect('/login')
    else:
         return HttpResponse("fail")

def login(request):
    return render(request,"login.html")

def login_validate(request):
    if request.method=='POST':   
        email=request.POST["email"]
        p=request.POST["password"]
        
        data=Student.objects.all().filter(email=email,password=p)
        
        # course_teacher = Enrollment.objects.all()
        
        if data:
        # if len(data)==1:   #duplicate element kadhayche astil tr te kadhane
            
            
            request.session["username"]=email   #session start
            
            id=0
            for i in data:
                id = i.id
            
                enrolled_data = Enrollment.objects.all().filter(student_id=id)
                if enrolled_data:
                    #enrolled course data start
                    
                    selected_ids=[]
                    for ii in enrolled_data:
                        print(ii.course_teacher_id)
                        selected_ids.append(ii.course_teacher_id)
                        
                    if selected_ids:
                        if request.session.get("username") is not None:
                            email = request.session.get("username")
                            student = get_object_or_404(Student, email=email)

                            for course_id in selected_ids:
                                course_teacher = get_object_or_404(CourseTeacher, id=course_id)
                                enrollment = Enrollment(student=student, course_teacher=course_teacher)
                                enrollment.save()

                            data2 = CourseTeacher.objects.filter(id__in=selected_ids)
                            data=Student.objects.all().filter(email=email)
                        else:
                            return redirect("/login")
                    else:
                        data2 = CourseTeacher.objects.none()

                    return render(request, 'selected_courses.html', {'data2': data2 ,'data':data})
                    #enrolled course data end
                else:
                    return redirect("/dashboard")
        else:
              return redirect("/login")
          
          
def dashboard(request):
    if request.session.get("username") is not None:
        email=request.session.get("username")
        data=Student.objects.all().filter(email=email)
        
        data1=CourseTeacher.objects.all()
        return render(request,"dashboard.html",{'data':data,'data1':data1})
        # return redirect("/table")
        
    else:
        return redirect("/")
    
    
    

    
def logout(request):
    del request.session["username"]     #end session
   
    return redirect("/") 

# @@@@@@@ not use

def table(request):
    data=CourseTeacher.objects.all()
    return render(request,"table.html",{'data':data})
    # return render(request,"dashboard.html",{'data1':data1})
    




# def submit(request):
#     if request.method == 'POST':
#         selected_ids = request.POST.getlist('selected_courses')
#         if selected_ids:
#             data = CourseTeacher.objects.all().filter(id__in=selected_ids)
            
            
            
#         else:
#             data = CourseTeacher.objects.none()
#         return render(request, 'selected_courses.html',{'data': data})
        
        
#     else:
#         # Handle GET request or any other logic here
#         return render(request, 'selected_courses.html')


def submit(request):
    if request.method == 'POST':
        selected_ids = request.POST.getlist('selected_courses')
        # print(selected_ids)
        if selected_ids:
            if request.session.get("username") is not None:
                email = request.session.get("username")
                student = get_object_or_404(Student, email=email)

                for course_id in selected_ids:
                    course_teacher = get_object_or_404(CourseTeacher, id=course_id)
                    enrollment = Enrollment(student=student, course_teacher=course_teacher)
                    enrollment.save()

                data2 = CourseTeacher.objects.filter(id__in=selected_ids)
                data=Student.objects.all().filter(email=email)
            else:
                return redirect("/login")
        else:
            data2 = CourseTeacher.objects.none()

        return render(request, 'selected_courses.html', {'data2': data2 ,'data':data})
    else:
        return render(request, 'selected_courses.html')

    
    
from django.shortcuts import render, get_object_or_404
from .models import Student

def student_list(request):
    students = Student.objects.all()
    return render(request, 'students/student_list.html', {'students': students})

def student_detail(request, pk):
    student = get_object_or_404(Student, pk=pk)
    return render(request, 'students/student_detail.html', {'student': student})


# optional

def delete(request):
    id = request.GET['id']
    Student.objects.all().filter(id=id).delete()
    return redirect("/submit")

def profilesubmit(request):
    if request.method=='POST':
        id=request.POST["id"]
        s_name=request.POST["s_name"]
        email=request.POST["email"]
       
        s_semester=request.POST["s_semester"]
        s_degree=request.POST["s_degree"]
        
        
        
        
        Student.objects.all().filter(id=id).update(s_name=s_name,email=email,s_semester=s_semester,s_degree=s_degree)    ##update 
        
        
        
        return redirect("/dashboard")
    else:
        return redirect("/dashboard")