from django.contrib import admin
from django.urls import path,include
from .import views

urlpatterns = [
    path('',views.index),
    path('registration',views.registration),
    path('login',views.login),
    path('login_validate',views.login_validate),
    path('dashboard',views.dashboard),
    path('logout',views.logout),
    
    path('table',views.table),
    path('submit',views.submit),
    # path('profile',views.profile),
    path('delete',views.delete),
    
     path('profilesubmit',views.profilesubmit),
]
