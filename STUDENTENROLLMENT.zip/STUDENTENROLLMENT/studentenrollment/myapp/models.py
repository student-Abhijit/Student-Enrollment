from django.db import models

# CourseTeacher model
class CourseTeacher(models.Model):
   
    course_name = models.CharField(max_length=200)
    teacher_name = models.CharField(max_length=200)

    def _str_(self):
        return self.course_name

# Student model
class Student(models.Model):
    s_name = models.CharField(max_length=200)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=50, default="0")
    s_semester = models.CharField(max_length=200)
    s_degree = models.CharField(max_length=200)
    courses = models.ManyToManyField(CourseTeacher, through='Enrollment')

    def _str_(self):
        return self.s_name

# Enrollment model
class Enrollment(models.Model): 
    enroll_date = models.DateField(auto_now_add=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course_teacher = models.ForeignKey(CourseTeacher, on_delete=models.CASCADE)